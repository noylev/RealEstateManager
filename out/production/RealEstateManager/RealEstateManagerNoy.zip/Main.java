
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        RealEstateManager realEstateManager= RealEstateManager.getInstance();
        Property apartment1 = new GardenApartment("TLV", "Ben Yehuda",4,5,20,3);


        System.out.println(apartment1.toString());

    }
}
